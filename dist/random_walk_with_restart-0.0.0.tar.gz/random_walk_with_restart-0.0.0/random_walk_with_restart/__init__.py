from .src import *

__copyright__    = 'Copyright (C) 2021 Tsukasa Maruyama'
__version__      = '0.0.0'
__license__      = 'BSD-3-Clause'
__author__       = 'onyankopon'
__author_email__ = 'engineer.tsukasa@gmail.com'
__url__          = 'http://github.com/onyanko-pon/random_walk_with_restart_python'

__all__ = [RWRGraph]